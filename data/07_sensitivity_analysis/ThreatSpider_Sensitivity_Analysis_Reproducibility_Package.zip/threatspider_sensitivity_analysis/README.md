# ThreatSpider Sensitivity Analysis Reproducibility Package

This package reproduces the sensitivity analysis reported for the autonomous-ship case study.

## Source data

The input file `input/risk_instances.csv` was extracted from:

`RAP_Risk_Analysis_Academic_Report(3).xlsx`

It contains the final approved Batch 12 population of **1,513 risk instances** across **34 components**.

## Randomized analysis

- Runs: **10,000**
- Random seed: **20260730**
- Random generator: **NumPy PCG64**
- Component multiplier: **Uniform(0.75, 1.25)**
- One independent multiplier is sampled for each component in each run.
- The same multiplier is applied to every risk instance associated with that component.
- Likelihood and Detectability are held fixed.
- Residual risk is recalculated as `Likelihood × Impact × multiplier × Detectability`.
- High/Critical means residual risk `>= 6`.
- Component ranking is based on maximum residual risk.
- Ranking stability is evaluated using Spearman rank correlation.

## Directional stress test

- Layer 1 impact multiplier: **1.25**
- Layer 2 impact multiplier: **1.25**
- Layer 3 impact multiplier: **0.75**

## Reproduced headline results

- Layer 3 retained the highest High/Critical rate in **10,000 of 10,000 runs**.
- Mean Spearman correlation: **0.915698**, reported as **0.916**.

## Run

From the package directory:

```bash
python scripts/run_sensitivity_analysis.py
```

Optional arguments:

```bash
python scripts/run_sensitivity_analysis.py --runs 10000 --seed 20260730
```

Generated files are written to `outputs/`.
