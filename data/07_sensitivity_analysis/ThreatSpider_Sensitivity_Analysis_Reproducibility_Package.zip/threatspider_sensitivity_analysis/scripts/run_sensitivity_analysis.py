#!/usr/bin/env python3
"""
ThreatSpider impact sensitivity analysis.

Method:
- Baseline residual risk = Likelihood × Impact × Detectability.
- Directional stress: Layer 1 and Layer 2 impacts × 1.25; Layer 3 impacts × 0.75.
- Randomized analysis: for each of 10,000 runs, independently sample one
  component-level multiplier m_c ~ U(0.75, 1.25), then apply the same multiplier
  to every risk instance belonging to component c.
- Likelihood and Detectability remain fixed.
- Severity thresholds: Low < 3; Medium [3,6); High [6,9); Critical >= 9.
- Layer High/Critical rate = number of records with residual risk >= 6 divided
  by all evaluated records in that layer.
- Component ranking stability is measured using Spearman correlation between
  baseline and perturbed component rankings based on maximum residual risk.

The fixed PCG64 seed makes the 10,000 randomized runs reproducible.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

DEFAULT_SEED = 20260730
DEFAULT_RUNS = 10000

LAYER_ORDER = ("Layer 1", "Layer 2", "Layer 3")


def severity(score: float) -> str:
    if score < 3.0:
        return "Low"
    if score < 6.0:
        return "Medium"
    if score < 9.0:
        return "High"
    return "Critical"


def average_ranks(values: np.ndarray) -> np.ndarray:
    """Return 1-based average ranks, including correct handling of ties."""
    order = np.argsort(values, kind="mergesort")
    ranks = np.empty(len(values), dtype=float)
    sorted_values = values[order]

    start = 0
    while start < len(values):
        end = start + 1
        while end < len(values) and sorted_values[end] == sorted_values[start]:
            end += 1
        average_rank = ((start + 1) + end) / 2.0
        ranks[order[start:end]] = average_rank
        start = end

    return ranks


def pearson_correlation(x: np.ndarray, y: np.ndarray) -> float:
    x_centered = x - x.mean()
    y_centered = y - y.mean()
    denominator = math.sqrt(float(np.dot(x_centered, x_centered) * np.dot(y_centered, y_centered)))
    if denominator == 0.0:
        return 0.0
    return float(np.dot(x_centered, y_centered) / denominator)


def spearman_correlation(x: np.ndarray, y: np.ndarray) -> float:
    return pearson_correlation(average_ranks(x), average_ranks(y))


def read_input(path: Path):
    records = []
    with path.open("r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            records.append({
                "id": int(row["ID"]),
                "component_id": int(row["ComponentID"]),
                "component": row["Component Name"],
                "layer": row["Layer"],
                "mitre_id": row["MITRE ID"],
                "consequence": row["Consequence"],
                "likelihood": float(row["Likelihood"]),
                "impact": float(row["Impact"]),
                "detectability": float(row["Detectability"]),
                "stored_residual_risk": float(row["Stored Residual Risk"]),
            })
    return records


def scenario_counts(scores: np.ndarray, record_layers: np.ndarray):
    result = {}
    for layer_index, layer_name in enumerate(LAYER_ORDER):
        mask = record_layers == layer_index
        layer_scores = scores[mask]
        counts = Counter(severity(float(score)) for score in layer_scores)
        total = int(mask.sum())
        hc_count = int(np.sum(layer_scores >= 6.0))
        result[layer_name] = {
            "Total": total,
            "Low": counts["Low"],
            "Medium": counts["Medium"],
            "High": counts["High"],
            "Critical": counts["Critical"],
            "High_Critical_Count": hc_count,
            "High_Critical_Rate": hc_count / total,
        }
    return result


def write_scenario_csv(path: Path, scenario_name: str, data: dict):
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([
            "Scenario", "Layer", "Total", "Low", "Medium", "High", "Critical",
            "High/Critical Count", "High/Critical Rate"
        ])
        for layer in LAYER_ORDER:
            row = data[layer]
            writer.writerow([
                scenario_name, layer, row["Total"], row["Low"], row["Medium"],
                row["High"], row["Critical"], row["High_Critical_Count"],
                row["High_Critical_Rate"]
            ])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "input" / "risk_instances.csv",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "outputs",
    )
    parser.add_argument("--runs", type=int, default=DEFAULT_RUNS)
    parser.add_argument("--seed", type=int, default=DEFAULT_SEED)
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    records = read_input(args.input)

    components = sorted({record["component"] for record in records})
    component_index = {component: idx for idx, component in enumerate(components)}
    layer_index = {layer: idx for idx, layer in enumerate(LAYER_ORDER)}

    base_scores = np.array([
        record["likelihood"] * record["impact"] * record["detectability"]
        for record in records
    ], dtype=float)
    record_components = np.array([
        component_index[record["component"]] for record in records
    ], dtype=int)
    record_layers = np.array([
        layer_index[record["layer"]] for record in records
    ], dtype=int)

    layer_totals = np.array([
        int(np.sum(record_layers == idx)) for idx in range(len(LAYER_ORDER))
    ], dtype=int)

    component_maxima = np.array([
        float(np.max(base_scores[record_components == idx]))
        for idx in range(len(components))
    ], dtype=float)

    component_layers = {}
    component_record_counts = Counter()
    for record in records:
        component_layers[record["component"]] = record["layer"]
        component_record_counts[record["component"]] += 1

    baseline = scenario_counts(base_scores, record_layers)

    directional_multiplier = np.where(record_layers < 2, 1.25, 0.75)
    directional_scores = base_scores * directional_multiplier
    directional = scenario_counts(directional_scores, record_layers)

    rng = np.random.Generator(np.random.PCG64(args.seed))
    run_rows = []
    layer_win_counts = Counter()
    correlations = []
    randomized_rates = np.empty((args.runs, 3), dtype=float)

    for run_number in range(1, args.runs + 1):
        component_multipliers = rng.uniform(0.75, 1.25, size=len(components))
        perturbed_scores = base_scores * component_multipliers[record_components]

        hc_counts = np.array([
            int(np.sum((perturbed_scores >= 6.0) & (record_layers == idx)))
            for idx in range(3)
        ], dtype=int)
        hc_rates = hc_counts / layer_totals
        randomized_rates[run_number - 1] = hc_rates

        maximum_rate = float(np.max(hc_rates))
        winners = [
            LAYER_ORDER[idx] for idx, rate in enumerate(hc_rates)
            if math.isclose(float(rate), maximum_rate, rel_tol=0.0, abs_tol=1e-15)
        ]
        winner = winners[0] if len(winners) == 1 else "Tie"
        layer_win_counts[winner] += 1

        perturbed_component_maxima = component_maxima * component_multipliers
        rho = spearman_correlation(component_maxima, perturbed_component_maxima)
        correlations.append(rho)

        run_rows.append([
            run_number,
            int(hc_counts[0]), float(hc_rates[0]),
            int(hc_counts[1]), float(hc_rates[1]),
            int(hc_counts[2]), float(hc_rates[2]),
            winner,
            rho,
        ])

    randomized_runs_path = args.output_dir / "randomized_runs.csv"
    with randomized_runs_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([
            "Run", "Layer 1 H/C Count", "Layer 1 H/C Rate",
            "Layer 2 H/C Count", "Layer 2 H/C Rate",
            "Layer 3 H/C Count", "Layer 3 H/C Rate",
            "Highest H/C Rate", "Spearman rho"
        ])
        writer.writerows(run_rows)

    write_scenario_csv(args.output_dir / "baseline_by_layer.csv", "Baseline", baseline)
    write_scenario_csv(
        args.output_dir / "directional_stress_by_layer.csv",
        "Directional stress",
        directional,
    )

    component_rows = []
    baseline_component_ranks = average_ranks(component_maxima)
    for idx, component in enumerate(components):
        component_rows.append([
            component,
            component_layers[component],
            component_record_counts[component],
            component_maxima[idx],
            baseline_component_ranks[idx],
        ])

    with (args.output_dir / "component_baseline.csv").open(
        "w", newline="", encoding="utf-8"
    ) as f:
        writer = csv.writer(f)
        writer.writerow([
            "Component", "Layer", "Risk Instance Count",
            "Maximum Baseline Residual Risk", "Baseline Rank"
        ])
        writer.writerows(component_rows)

    correlations_array = np.asarray(correlations, dtype=float)
    summary = {
        "input_records": len(records),
        "components": len(components),
        "runs": args.runs,
        "seed": args.seed,
        "random_generator": "NumPy PCG64",
        "multiplier_distribution": "Uniform(0.75, 1.25), independently per component and run",
        "layer_3_highest_rate_runs": layer_win_counts["Layer 3"],
        "layer_3_highest_rate_percentage": layer_win_counts["Layer 3"] / args.runs,
        "ties": layer_win_counts["Tie"],
        "mean_spearman_rho": float(correlations_array.mean()),
        "median_spearman_rho": float(np.median(correlations_array)),
        "min_spearman_rho": float(correlations_array.min()),
        "max_spearman_rho": float(correlations_array.max()),
        "baseline": baseline,
        "directional_stress": directional,
        "randomized_rate_statistics": {},
    }

    for idx, layer in enumerate(LAYER_ORDER):
        values = randomized_rates[:, idx]
        summary["randomized_rate_statistics"][layer] = {
            "mean": float(values.mean()),
            "median": float(np.median(values)),
            "minimum": float(values.min()),
            "maximum": float(values.max()),
            "p025": float(np.quantile(values, 0.025)),
            "p975": float(np.quantile(values, 0.975)),
        }

    with (args.output_dir / "summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)

    print(json.dumps({
        "records": len(records),
        "components": len(components),
        "runs": args.runs,
        "seed": args.seed,
        "layer_3_wins": layer_win_counts["Layer 3"],
        "mean_spearman_rho": summary["mean_spearman_rho"],
    }, indent=2))


if __name__ == "__main__":
    main()
